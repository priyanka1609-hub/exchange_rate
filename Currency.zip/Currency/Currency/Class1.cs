﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Diagnostics;

namespace Currency
{
    public class Class1
    {
        public static void Main(string[] args)
        {
            


            Console.WriteLine("******************** Welcome to Exchange Rate Program ********************");
            Console.WriteLine("Chose the Options as mentioned below : ");
            Console.WriteLine("Option A : If you want to get exchnage rate of amount for your currency ");
            Console.WriteLine("Option B : If you want to get exchnage rate of amount for your currency for particular date you want");

            Console.Write("Choose option : ");
            string option = Console.ReadLine();
            Console.WriteLine("Option Selected -->" + option);

            if (option == "A")
            {

                SqlConnection conn = new SqlConnection("server=DESKTOP-GMMP0C8;Database=currencyexchange;Integrated Security=True");
                conn.Open();
                SqlCommand cmd = new SqlCommand("Select From_Currency,To_Currency, cast(Exchange_Rate as float),(cast(Exchange_Rate as float) * cast(@Amount as float))  from Currency_rateDemo where From_Currency =@From_Currency and To_Currency =@To_Currency", conn);

                Console.Write("Enter From Currency : ");
                string Currency = Console.ReadLine();
                Console.WriteLine("From Currency -->" + Currency);
                cmd.Parameters.AddWithValue("@From_Currency", Currency);

                Console.Write("Enter To Currency : ");
                string ToCurrency = Console.ReadLine();
                Console.WriteLine("To Currency -->" + ToCurrency);
                cmd.Parameters.AddWithValue("@To_Currency", ToCurrency);

                Console.Write("Enter Amount : ");
                // int Amount = Convert.ToInt32(Console.ReadLine());---CAST(((Exchange_Rate)*@Amount) AS varchar)
                string Amount = Console.ReadLine();
                Console.WriteLine("Amount -->" + Amount);
                cmd.Parameters.AddWithValue("@Amount", Amount);

               

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Console.Write("\nFrom Currency --->  ");
                    Console.WriteLine("{0}", reader.GetString(0));
                    Console.Write("To Currency --->  ");
                    Console.WriteLine("{0}", reader.GetString(1));
                    Console.Write("Exchange Rate --->  ");
                    Console.WriteLine("{0}", reader.GetDouble(2));
                    Console.Write("Calculated Amount for Exchange Rate --->  ");
                    Console.WriteLine("{0}", reader.GetDouble(3));
                   //                   Console.WriteLine("{0},{1},{2},{3}", reader.GetString(0), reader.GetString(1), reader.GetDouble(2), reader.GetDouble(3));
                    Console.Write("********************  End of the Program  ********************  \n");

                }


                reader.Close();
                conn.Close();

                if (Debugger.IsAttached)
                {
                    Console.ReadLine();
                }
            }
            //////Secnaro optional input Date
            else if (option == "B")
            {
                SqlConnection con = new SqlConnection("server=DESKTOP-GMMP0C8;Database=currencyexchange;Integrated Security=True");
                con.Open();
               

                SqlCommand cm = new SqlCommand("Select From_Currency,To_Currency, cast(Exchange_Rate as float),(cast(Exchange_Rate as float) * cast(@Amount as float))  from Currency_rateDemo where  From_Currency =@From_Currency and To_Currency =@To_Currency and Date =@Date", con);
               

                Console.Write("Enter From Currency : ");
                string Currency1 = Console.ReadLine();

                Console.WriteLine("From Currency -->" + Currency1);
                cm.Parameters.AddWithValue("@From_Currency", Currency1);

                Console.Write("Enter From Currency : ");
                string ToCurrency2 = Console.ReadLine();
                Console.WriteLine("To Currency -->" + ToCurrency2);
                cm.Parameters.AddWithValue("@To_Currency", ToCurrency2);

                Console.Write("Enter Amount : ");
                int Amount1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Amount -->" + Amount1);
                cm.Parameters.AddWithValue("@Amount", Amount1);

                Console.Write("Enter Date in (YYYY-MM-DD) : ");
                string Date = Console.ReadLine();
                Console.WriteLine("Date -->" + Date);
                cm.Parameters.AddWithValue("@Date", Date);

                SqlDataReader reader1 = cm.ExecuteReader();
                while (reader1.Read())
                {
                   

                    Console.Write("\nFrom Currency --->  ");
                    Console.WriteLine("{0}", reader1.GetString(0));
                    Console.Write("To Currency --->  ");
                    Console.WriteLine("{0}", reader1.GetString(1));
                    Console.Write("Exchange Rate --->  ");
                    Console.WriteLine("{0}", reader1.GetDouble(2));
                    Console.Write("Calculated Amount for Exchange Rate --->  ");
                    Console.WriteLine("{0}", reader1.GetDouble(3));
                    Console.Write("********************  End of the Program  ********************  \n");

                }


                reader1.Close();
                con.Close();

                if (Debugger.IsAttached)
                {
                    Console.ReadLine();
                }
            }
            else
            {
                Console.WriteLine("Please Enter Valid Input");
            }
        }
    }

}