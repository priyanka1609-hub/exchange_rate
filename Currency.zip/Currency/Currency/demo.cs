﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Currency
{
    class demo
    {
         static void Main(string[] args)
        {
            //set the connection string
            string connString = @"Server =DESKTOP-GMMP0C8; Database = currencyexchange; Trusted_Connection = True;";

            //variables to store the query results
           // int empID;
            string From_Currency,To_Currency;

            try
            {
                //sql connection object
                using (SqlConnection conn = new SqlConnection(connString))
                {

                    //retrieve the SQL Server instance version
                    string query = @"SELECT From_Currency,To_Currency
                                     FROM Currency_rate ";
                    //define the SqlCommand object
                    SqlCommand cmd = new SqlCommand(query, conn);

                    //open connection
                    conn.Open();

                    //execute the SQLCommand
                    SqlDataReader dr = cmd.ExecuteReader();

                    Console.WriteLine(Environment.NewLine + "Retrieving data from database..." + Environment.NewLine);
                    Console.WriteLine("Retrieved records:");

                    //check if there are records
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            //empID = dr.GetInt32(0);
                            From_Currency = dr.GetString(1);
                           To_Currency = dr.GetString(2);
                           
                            //display retrieved record
                            Console.WriteLine("{1},{2}", From_Currency, To_Currency);
                        }
                    }
                    else
                    {
                        Console.WriteLine("No data found.");
                    }

                    //close data reader
                    dr.Close();

                    //close connection
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                //display error message
                Console.WriteLine("Exception: " + ex.Message);
            }


        }
    }
}
    

