﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Exchange_rate.Models;
using Newtonsoft.Json;
using System.IO;

namespace Exchange_rate.Controllers
{
    public class HomeController : Controller
    {
        private currencyexchangeEntities db = new currencyexchangeEntities();

        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View(db.Currency_rate.ToList());
        }

        //
        // GET: /Home/Details/5

        /// <summary>
        /// /priyanka
        public ActionResult GetData()
        {
            using (currencyexchangeEntities db = new currencyexchangeEntities())
            {
                List<Currency_rate> productList = db.Currency_rate.ToList<Currency_rate>();
                return Json(new { data = productList }, JsonRequestBehavior.AllowGet);
            }
        }  
  
        [HttpPost]  
        public ActionResult Upload(HttpPostedFileBase jsonFile)  
        {  
                using (currencyexchangeEntities db = new currencyexchangeEntities())  
                {  
                    if (!jsonFile.FileName.EndsWith(".json"))  
                    {  
                        ViewBag.Error = "Invalid file type(Only JSON file allowed)";  
                    }  
                    else  
                    {  
                        jsonFile.SaveAs(Server.MapPath("~/FileUpload/" + Path.GetFileName(jsonFile.FileName)));
                        StreamReader streamReader = new StreamReader(Server.MapPath("~/FileUpload/" + Path.GetFileName(jsonFile.FileName)));  
                        string data = streamReader.ReadToEnd();  
                        List<Currency_rate> products = JsonConvert.DeserializeObject<List<Currency_rate>>(data);  
  
                        products.ForEach(p =>  
                        {  
                            Currency_rate product = new Currency_rate()  
                            {
                                CurrencyCode = p.CurrencyCode,  
                                CurrencyRate = p.CurrencyRate,  
                                Date = p.Date,  
                            };  
                            db.Currency_rate.Add(product);  
                            db.SaveChanges();  
                        });  
                        ViewBag.Success = "File uploaded Successfully..";  
                    }  
                }  
            return View("Index");  
        }  
        /// /////////////////
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult Details(int id = 0)
        {
            Currency_rate currency_rate = db.Currency_rate.Find(id);
            if (currency_rate == null)
            {
                return HttpNotFound();
            }
            return View(currency_rate);
        }

        //
        // GET: /Home/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Home/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Currency_rate currency_rate)
        {
            if (ModelState.IsValid)
            {
                db.Currency_rate.Add(currency_rate);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(currency_rate);
        }

        //
        // GET: /Home/Edit/5

        public ActionResult Edit(int id = 0)
        {
            Currency_rate currency_rate = db.Currency_rate.Find(id);
            if (currency_rate == null)
            {
                return HttpNotFound();
            }
            return View(currency_rate);
        }

        //
        // POST: /Home/Edit/5

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Currency_rate currency_rate)
        {
            if (ModelState.IsValid)
            {
                db.Entry(currency_rate).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(currency_rate);
        }

        //
        // GET: /Home/Delete/5

        public ActionResult Delete(int id = 0)
        {
            Currency_rate currency_rate = db.Currency_rate.Find(id);
            if (currency_rate == null)
            {
                return HttpNotFound();
            }
            return View(currency_rate);
        }

        //
        // POST: /Home/Delete/5

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Currency_rate currency_rate = db.Currency_rate.Find(id);
            db.Currency_rate.Remove(currency_rate);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}